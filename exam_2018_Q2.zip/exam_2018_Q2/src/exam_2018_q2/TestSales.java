/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam_2018_q2;

/**
 *
 * @author KID DANGER
 */
public class TestSales {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Sales ss = new Sales();
        
        ss.getEmployeeSales();
        
        System.out.println("\n\nEmployee Sales Report");
        System.out.println("-----------------------");
        
        System.out.println("Employee:    "+ss.employeeName);
        System.out.println("Total Sold:  "+ss.totalSales());
        System.out.println("-----------------------");
        
        System.out.println("SALES COUNT:    "+ss.sales.length);
        System.out.println("Average Sales:  "+ss.averageSales());
    }
    
}
