/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam_2018_q2;

import java.util.Scanner;

/**
 *
 * @author KID DANGER
 */
public class Sales {
    
    String employeeName;
    
    float [] sales = new float[0]; 
    
    public void getEmployeeSales(){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the employee name: ");
        employeeName = sc.nextLine();
        
        int count = 1;
        
        float sale = 1;
        
        while(sale!=0){
            
            System.out.println("Enter the sale "+count);
            sale = sc.nextFloat();
            
            if(sale>0){
                
            float [] sale_t = sales;
            
            sales = new float[count];
            
            for(int a=0;a<sale_t.length;a++){
                sales[a] = sale_t[a];
            }
            sales[sales.length-1] = sale;
            
            count+=1;
            }else if(sale!=0){
                System.out.println("You have entered a sale less than zero.");
                System.out.println("Please enter the sale again.");
            }
        }
    }
    
    public float totalSales(){
        float total = 0;
        for(int a=0;a<sales.length;a++){
            total+=sales[a];
        }
        return total;
    }
    
    public float averageSales(){
        return (totalSales()/sales.length);
    }
}
