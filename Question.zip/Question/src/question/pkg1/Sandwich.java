/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question.pkg1;

/**
 *
 * @author 21007487
 */
public class Sandwich {
    
    private String main_ingredient;
    
    private String bread_type;
    
    private double price;

    public void setMain_ingredient(String main_ingredient) {
        this.main_ingredient = main_ingredient;
    }

    public void setBread_type(String bread_type) {
        this.bread_type = bread_type;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getMain_ingredient() {
        return main_ingredient;
    }

    public String getBread_type() {
        return bread_type;
    }

    public double getPrice() {
        return price;
    }
    
    
    
}
