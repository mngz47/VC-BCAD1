/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question.pkg1;

/**
 *
 * @author 21007487
 */
public class TestSandwich {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        Sandwich sw = new Sandwich();
        
        sw.setMain_ingredient("Tuna");
        sw.setBread_type("Wheat");
        sw.setPrice(4.99);
    
        System.out.println("The Details Are: "+ 
                 sw.getMain_ingredient() +"\n"+
                 sw.getBread_type() +"\n"+
                 sw.getPrice());
        
    }
    
}
