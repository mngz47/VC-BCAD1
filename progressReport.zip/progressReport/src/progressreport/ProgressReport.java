/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressreport;

import java.util.Scanner;

/**
 *
 * @author 21007487
 */
public class ProgressReport {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of students\n");
        int studentCount = sc.nextInt();
        
        
        int passed = 0;
        int failed = 0;
        
        
         for (int i = 0; i < studentCount; i++) {
            System.out.println("Did the student "+(i+1)+" pass (y/n) \n");
            if(sc.next().equals("y")){
                passed+=1;
            }else{
                failed+=1;
            }
            
            /*
            
            switch(num){
            case 1: passed++;break;
            case 2: failed++;break;
            default: System.out.println("Enter value between 1 and 2");break;
            }
            
            */
            
            
            
         }
         
         System.out.println("Report: \n");
         System.out.println("Number of students: "+studentCount);
         System.out.println("Number passed: "+passed);
         System.out.println("Number failed: "+failed);
         
         double perc = (failed * 100/studentCount); //  (failed/studentCount * 100)
         
         System.out.println("Percentage of Failure: "+ perc);
         
    }
    
}
