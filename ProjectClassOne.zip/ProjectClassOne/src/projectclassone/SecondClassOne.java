/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectclassone;

/**
 *
 * @author 21007487
 */
public class SecondClassOne {
    
    String name= "";
    
    public static void saySomething(){
        
        System.out.println("hello from second class");
        
        
    }
    
}
