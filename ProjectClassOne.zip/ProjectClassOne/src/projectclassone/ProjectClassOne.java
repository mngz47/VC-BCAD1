/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectclassone;

/**
 *
 * @author 21007487
 */
public class ProjectClassOne {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        
        
        Methods -  Gets Sets
        Nested Classes
        
        create the object of the class
        
        */
        
        SecondClassOne sco = new SecondClassOne();
        sco.name = "Jigga";

        System.out.println(sco.name);
        
        SecondClassOne.saySomething();
        
    }
    
}
