/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parallelarraysone;

/**
 *
 * @author KID DANGER
 */
public class ParallelArraysOne {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      String [] menu = {"Burger","Coke","Chips"};
      int [] prices = {45,20,25};
      
      System.out.println("The menu is: ");
        for (int i = 0; i < 3; i++) {
            System.out.println(menu[i] +"\t"+prices[i]);
        }
        
        twoDimensionalArray();
      
    }
    
    
    
    public static void twoDimensionalArray(){
        int [][] hotelPrices = {{23,45},{45,34},};
        System.out.println("Hotel Prices");
        for (int i = 0; i < hotelPrices.length; i++) {
            for (int j = 0; j < hotelPrices[i].length; j++) {
                
                System.out.println(hotelPrices[i][j]);
                
            }
        }
        
        
    }
    
    //page 409 3a 3b
    //2017 Past Exam
    
}
