/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question_3;

/**
 *
 * @author KID DANGER
 */
public class Course_Details {
    
    private String courseName;
    
    private int studentNumbers;
    
    private String lecturer;
    
    private int venue;

    public String getCourseName() {
        return courseName;
    }

    public int getStudentNumbers() {
        return studentNumbers;
    }

    public String getLecturer() {
        return lecturer;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setStudentNumbers(int studentNumbers) {
        this.studentNumbers = studentNumbers;
    }

    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }

    public int getVenue() {
        return venue;
    }

    public void setVenue(int venue) {
        this.venue = venue;
    }
    
    
    
    public void assignVenue(){
        int aa = (int)Math.round(Math.random()*3);
        while(!(aa>0 && aa<4)){
            aa = (int)Math.round(Math.random()*3);
        }
        this.setVenue(aa);
    }
    
}
