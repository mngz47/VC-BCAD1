/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question_3;

import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author KID DANGER
 */
public class Course {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Allocate course data
        Course_Details[] c_d = new Course_Details[3];
        
        c_d[0] = new Course_Details();
        c_d[0].setCourseName("Diploma in Software Development");
        c_d[0].setStudentNumbers(35);
        c_d[0].setLecturer("Mr Jones");
        c_d[0].assignVenue();
        
        c_d[1] = new Course_Details();
        c_d[1].setCourseName("Diploma in Web Development");
        c_d[1].setStudentNumbers(28);
        c_d[1].setLecturer("Mrs Smith");
        c_d[1].assignVenue();
        
        c_d[2] = new Course_Details();
        c_d[2].setCourseName("Diploma in Data Metrics");
        c_d[2].setStudentNumbers(39);
        c_d[2].setLecturer("Mr Ntsinga");
        c_d[2].assignVenue();
        
        String stop = "n";
        
        while(!stop.equals("y")){//continue printing different course information until user inputs (y) to stop
            int code = Integer.parseInt(JOptionPane.showInputDialog("Select from the following to view module details\n1)DISD\n2)DIWD\n3)DIDM "));//prompt user for which index of information to print out
            Course.printCourseReport(c_d[code]);
            stop = JOptionPane.showInputDialog("Enter (y) to exit or any other key to continue.");
        }
    }
    
    public static void printCourseReport(Course_Details c_d){
        
        System.out.println("COURSE REPORT "+(new Date()));
        System.out.println("*****************************");
        System.out.println("COURSE\t"+c_d.getCourseName());
        System.out.println("STUDENT NUMBERS\t"+c_d.getStudentNumbers());
        System.out.println("LECTURER\t"+c_d.getLecturer());
        System.out.println("VENUE\tVenue"+c_d.getVenue());
        
    }
    
}
