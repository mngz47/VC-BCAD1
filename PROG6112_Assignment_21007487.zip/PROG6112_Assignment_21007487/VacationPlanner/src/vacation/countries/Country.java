/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vacation.countries;

/**
 *
 * @author KID DANGER
 */
public class Country { //has subclass
   
                         //[hotels][museums] 
    String [][] countries = 
            
    {
         {"Australia","Afghanistan","Albania","Algeria","Andorra"},  
         {"Antigua and Barbuda","Argentina","Armenia","Australia","Austria"},  
         {"Azerbaijan","Bahamas","Bahrain","Barbados","Belarus"},
         {"Belize","Benin","Bhutan","Bolivia","Botswana"},
         {"Brazil","Brunei","Bulgaria","",""},
         {"Belgium","Burkina Faso","Burundi","Cabo Verde","Cambodia"},  
         {"Cameroon","Canada","Chad","Chile","China"},
         {"Colombia","Comoros","Costa Rica","Croatia","Cuba"},
         {"Cyprus","Denmark","Djibouti","Dominica","Ecuador"},
         {"Egypt","Eritrea","Estonia","Ethiopia","Fiji"},  
         {"Finland","France","Gabon","Gambia","Georgia"},
         {"Germany","Ghana","Greece","Grenada","Guatemala"},
         {"Guinea","Guyana","Haiti","Honduras","Hungary"},
         {"India","Indonesia","Iran","Iraq","Ireland"},
         {"Israel","Italy","Jamaica","Japan","Jordan"},
         {"Kazakhstan","Kenya","Kiribati","Kuwait","Kyrgyzstan"},
         {"Laos","Latvia","Liechtenstein","Luxembourg","Malawi"},
         {"Lebanon","Lithuania","Malaysia","Mali","Libya"},
         {"Lesotho","Liberia","Malta","Mauritania","Mauritius"},
         {"Mexico","Moldova","Lithuania","Monaco","Mongolia"},
         {"Micronesia","Morocco","Mozambique","Namibia","Nepal"},
    };
    
    void updateCountry(int hotels,int museums,String val){
       
      countries[hotels][museums] = val; //Improve data accuracy
       
   } 
    
   void showCountries(){ //show all countries
       
       for (int i = 0; i < 20; i++) {
           for (int j = 0; j < 5; j++) {
               System.out.print(countries[i][j]+"\t");
           }
           System.out.println();
       }
   } 
    
}
