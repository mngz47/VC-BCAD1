/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vacation.countries;

import java.util.Scanner;

/**
 *
 * @author 21007487
 */
public class VacationPlanner extends Country {

    /**
     * @param args the command line arguments
     */
   
                                            
    
    int hotels;
    
    int museums;
    
   void index(){
       Scanner sc = new Scanner(System.in);
       
       System.out.println("Vacation Planner");
       System.out.println("*****************");
       System.out.println("Find A country with the best options!");
       System.out.println("*****************");
       
       System.out.println("Enter number of hotel options you want MAX(20)");
       hotels = Integer.parseInt(sc.next());
       System.out.println("Enter number of museum options you want MAX(4)");
       museums = Integer.parseInt(sc.next());
       
       hotels--;
       museums--;
       
        if(hotels<20 && hotels>0){ //validate data
            if(museums<5 && museums>0){
                System.out.println("The country for your is "+countries[hotels][museums]); //make country selection
            
            System.out.println("Are you happy with your result? (y/n)");
        String feedback = sc.next();
        
        if(feedback.equals("n")){
            
            System.out.println("Update with more accurate result");
            updateCountry(hotels,museums,sc.next());
            showCountries();
            
        }else{
            System.out.println("Enjoy Your Trip!!");
        System.exit(0);
        }
            
            }else{
        System.out.println("Only countries with MAX 5 museums are listed");        
            }   
        }else{
        System.out.println("Only countries with MAX 20 top hotels are listed");    
        } 
   }
}
