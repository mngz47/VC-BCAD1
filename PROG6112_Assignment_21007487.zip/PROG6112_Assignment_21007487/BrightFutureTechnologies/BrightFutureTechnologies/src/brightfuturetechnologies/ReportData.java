/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package brightfuturetechnologies;

/**
 *
 * @author 21007487
 */
public class ReportData {
    
    int product_count;
    String [][] products;
    String [] field_labels;
    
    ReportData(int pc,String[][] p,String[] fl){ //fetch product data
        this.product_count = pc;
        this.products = p;
        this.field_labels = fl;
    }
    
    String [] product_category = {"Desktop Computer","Laptop","Tablet","Printer","Gaming Console"};
    String [] warranty = {"6 months","2 years"};
    
    void printReport(){ // show product data
        System.out.println("\n\nPRODUCT REPORT");
        System.out.println("**************");
        
        
        for(int a=0;a<product_count;a++){
            System.out.println("PRODUCT "+(a+1));
            System.out.println("**************");
                for(int aa=0;aa<field_labels.length;aa++){
        
                    String val = (aa==2? product_category[ Integer.parseInt(products[a][aa])-1]  : (aa==3? warranty[Integer.parseInt(products[a][aa])-1] : products[a][aa])); //User friendly values 
                    
                    String format = "%-40s%s%n";
                    System.out.printf(format, field_labels[aa],val);
                    
                }
            System.out.println("**************");
        }
    }
    
    //get and set methods
    
    String getProductCode(int row){
        return products[row][0]; 
    }
    
    void setProductCode(int row,String val){
        products[row][0] = val;
    }
    
    
    String getProductName(int row){
        return products[row][1]; 
    }
    
    void setProductName(int row,String val){
        products[row][1] = val;
    }
    
    String getProductCategory(int row){
        return products[row][2]; 
    }
    
    void setProductCategory(int row,String val){
        products[row][2] = val;
    }
    
    String getProductWarranty(int row){
        return products[row][0]; 
    }
    
    void setProductWarranty(int row,String val){
        products[row][0] = val;
    }
    
    String getProductPrice(int row){
        return products[row][0]; 
    }
    
    void setProductPrice(int row,String val){
        products[row][0] = val;
    }
    
    String getProductLevel(int row){
        return products[row][0]; 
    }
    
    void setProductLevel(int row,String val){
        products[row][0] = val;
    }
    
    String getProductSupplier(int row){
        return products[row][0]; 
    }
    
    void setProductSupplier(int row,String val){
        products[row][0] = val;
    }
       
}
