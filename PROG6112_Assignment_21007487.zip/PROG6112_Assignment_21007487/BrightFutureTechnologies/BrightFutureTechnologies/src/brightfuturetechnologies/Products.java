/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package brightfuturetechnologies;

import java.util.Scanner;

/**
 *
 * @author 21007487
 */
public class Products {

    
    String [] fields = {    //hold the field prompts
    "Enter the product code:",
    "Enter the product name:",
    "Select the product category:"+
            "\n(1)Desktop Computer"+
            "\n(2)Laptop"+
            "\n(3)Tablet"+
            "\n(4)Printer"+
            "\n(5)Gaming Console",
    "Enter Warranty:"+
            "\n(1) 6 months"+
            "\n(2) 2 years",
    "Enter the price for ",
    "Enter the stock level for ",
    "Enter the supplier for "
    };
            
    String [] field_labels = {   //hold the field labels
        "PRODUCT CODE:",
        "PRODUCT NAME:",
        "PRODUCT WARRANTY:",
        "PRODUCT CATEGORY:",
        "PRODUCT PRICE:",
        "PRODUCT STOCK LEVELS:",
        "PRODUCT SUPPLIER:"
    };
    
    int product_count = 0; //counts the number of products that have been added
    int max_product = 10; //max number of records
                                //[rows][cols]
    String [][] products = new String[max_product][7];  //used to store the products
   
    void index(){
        //Menu
        System.out.println("\n\nBRIGHT FUTURE TECHNOLOGIES APPLICATION");
        System.out.println("**************************************");
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new product.");
        System.out.println("(2) Search for a product.");
        System.out.println("(3) Update a product.");
        System.out.println("(4) Delete a product.");
        System.out.println("(5) Print report.");
        System.out.println("(6) Exit Application");
        
        Scanner sc = new Scanner(System.in);//get menu selection
        switch (Integer.parseInt(sc.next())){
            case 1 :  newProduct();break;
            case 2 :  searchProduct();break;
            case 3 :  updateProduct();break;
            case 4 :  deleteProduct();break;
            case 5 :  new ReportData(product_count,products,field_labels).printReport();break;
            case 6 :  System.exit(0);break;
            default : index();
        }
    }
   
    void newProduct(){
        System.out.println("\n\nCAPTURE A NEW PRODUCT");
        System.out.println("*********************");
        
        Scanner sc = new Scanner(System.in);
        String product_name = "";
        
            if(product_count<products.length){
                for(int aa=0;aa<fields.length;aa++){
                
                System.out.println(fields[aa]+(aa>3?product_name+":":"")); //prompt product field
                products[product_count][aa] = sc.next(); //set product field
                    switch (aa) {
                        case 1:
                            product_name = products[product_count][aa];
                            break;
                        case 2:
                            while((Integer.parseInt(products[product_count][aa])<1) || (Integer.parseInt(products[product_count][aa])>5)){ //validating category
                                System.out.println(fields[aa]);
                                products[product_count][aa] = sc.next();
                            }       break;
                        case 3:
                            while((Integer.parseInt(products[product_count][aa])!=1 && Integer.parseInt(products[product_count][aa])!=2)){ //validating warranty
                                System.out.println(fields[aa]);
                                products[product_count][aa] = sc.next();
                            }       break;
                        default:
                            break;
                    }
                }
                  System.out.println("Product Saved - Max Product(10)"); 
            }else{
                System.out.println("Max Product Reached");
            }
        product_count+=1;
        index(); //return to main menu
    }
    
    void searchProduct(){
        String product_code;
        
        System.out.println("\n\nPlease enter the product code to search:");
        Scanner sc = new Scanner(System.in);
        product_code = sc.next();
        
        boolean found = false;
        
        
        for(int a=0;a<product_count;a++){ //iterate throuh the rows
            if(products[a][0].equals(product_code)){ //match product code
                  System.out.println("**************************");
                  System.out.println("PRODUCT SEARCH RESULTS");
                  System.out.println("***************************");
                    
                for(int aa=0;aa<fields.length;aa++){
                   
                    String format = "%-40s%s%n";
                    System.out.printf(format, field_labels[aa],products[a][aa]);
                    
                }
                found = true;
            } 
        }
        if(!found){
            System.out.println("Product Not Found.");
        }
        index();
    }
    
    void updateProduct(){ //update product
         String product_code;
         int product_row = -1;
         int product_col = -1;
         String new_value;
        
        System.out.println("\n\nPlease enter the product code to update:");
        Scanner sc = new Scanner(System.in);
        product_code = sc.next(); //fetch product code from user
        
        for(int a=0;a<product_count;a++){
            if(products[a][0].equals(product_code)){
                product_row = a;
            }
        }
        
        if(product_row==-1){
            System.out.println("Product Not Found.");
        }else{
            
            
            while(product_col<0 || product_col>6){
            
            System.out.println("Select field:");
            for(int a=0;a<field_labels.length;a++){
            System.out.println("("+a+") "+field_labels[a]);
            }
            
            product_col = Integer.parseInt(sc.next());
            }
        
            System.out.println("Please enter new value of field ("+field_labels[product_col]+"):");
            new_value = sc.next();
        
            products[product_row][product_col] = new_value;
            System.out.println("Product Updated");
        }
        index();
    }
    
    void deleteProduct(){  //removing product
        String product_code;
        
        System.out.println("\n\nPlease enter the product code to delete:");
        Scanner sc = new Scanner(System.in);
        product_code = sc.next();
        
        int product_row = -1;
        
        for(int a=0;a<product_count;a++){
            if(products[a][0].equals(product_code)){
                product_row = a;
            }
        }
        
        String [][] product_temp = products;
        products = new String[10][7];
        
        if(product_row==-1){
            System.out.println("Product Not Found.");
        }else{
            
            for(int a=0;a<product_count;a++){
                for(int aa=0;aa<fields.length;aa++){
                    if(a!=product_row){
                        products[a][aa] = product_temp[a][aa]; //skip field being deleted
                    }else if(a>product_row){
                        products[a-1][aa] = product_temp[a-1][aa]; //accomodate gap space as result of skipping field
                    }
                }
            }
            product_count-=1;
            System.out.println("Product Deleted");
        }
        index();
    } 
}
