/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraymethods;

/**
 *
 * @author 21007487
 */
public class ArrayMethods {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int [] values = {45,16,22,19,83,33,100,-5,6,15};
        
        //methods
        //print the array
        //sum of the values in the array
        //reverse the array
        
        display(values);
        sumArray(values);
        reverseArray(values);
        findAverage(values);
    }
    
    public static void display(int [] values){
        for (int i = 0; i < values.length; i++) {
            System.out.print(values[i]+" ");
        }
    }
    
    public static void sumArray(int [] values){
        int total = 0;
        for (int i = 0; i < values.length; i++) {
            total+=values[i];
        }
        System.out.println("Total in array: "+total);
    }
    
     public static int getSumArray(int [] values){
        int total = 0;
        for (int i = 0; i < values.length; i++) {
            total+=values[i];
        }
        return total;
    }
    
    public static void reverseArray(int [] values){
        System.out.println("Reversed Array");
        for (int i = values.length-1; i>-1; i--) {
            System.out.print(values[i]+" ");
        }
    }
    
    //method that calculates the average
    //output the values greater than the average
    
    public static void findAverage(int [] values){
        
        int average = getSumArray(values)/values.length;
        System.out.println("The average is : "+average);
        System.out.println("Values greater than average : ");
        for (int i = 0; i < values.length; i++) {
            System.out.print((values[i]>average?values[i]:""));
        }
        
        
    }
    
    
}
