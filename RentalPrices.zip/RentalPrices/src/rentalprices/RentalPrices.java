/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalprices;

import java.util.Scanner;

/**
 *
 * @author KID DANGER
 */
public class RentalPrices {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
       
        
        int [][] rentals = 
        
        {
            {400,450,510}, 
            {500,560,630},
            {625,676,740},
            {1000,1250,1600}
        };
        
        
        
        
        Scanner sc = new Scanner(System.in);
        int floor = 0;
        int rooms = 0;
        
        while(floor<rentals.length && rooms<rentals[floor].length){
             
        System.out.println("Enter floor number");
        floor = sc.nextInt();
        System.out.println("Enter number of rooms");
        rooms = sc.nextInt();
        
        
        System.out.println("This is your rent R"+rentals[floor][rooms]);
        
        }
       
        
    }
    
    /*
    
     //declare the array

     int [][] rents = {{400,450,510},

              {500,560,630},

              {625,676,740},

              {1000,1250,1600}};

     

     //jop

     // prompt the user to enter the floor they wish to live on

     String entry;

     int floor; // to hold the floor #

     int bedrooms; // to hold the # of bedrooms

     

     JOptionPane.showMessageDialog(null,"***Welcome to Java Apartments***");

     entry = JOptionPane.showInputDialog(null, "Enter a floor number: \n"

         + " 0 - Basement \n"

         + " 1 - 1st floor \n"

         + " 2 - 2nd floor \n"

         + " 3 - 3rd floor");

     floor = Integer.parseInt(entry);

     

     // prompt for # of bedrooms

    entry = JOptionPane.showInputDialog(null, "Enter # of bedrooms: ");

    bedrooms = Integer.parseInt(entry);

     

     //output based on your info provided

     JOptionPane.showMessageDialog(null, "The rent for "+ bedrooms  

         +" roomed apartment on floor " +floor + " will be "

         + rents[floor][bedrooms]);

     JOptionPane.showMessageDialog(null,"The End");

  }
    
    */
    
}
