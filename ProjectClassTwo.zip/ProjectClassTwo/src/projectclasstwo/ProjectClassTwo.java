/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectclasstwo;

/**
 *
 * @author 21007487
 */
public class ProjectClassTwo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ThirdClass td = new ThirdClass();
        
        
        // information hidden pg_137-143
        // create gets and sets per varible
        
        
        td.setFirstName("John");
        td.setLastName("Doe");
        td.setAge(21);

        System.out.println(td.getFirstName());
        System.out.println(td.getLastName());
        System.out.println(td.getAge());
        
        td.setFirstName("Mongezi");
        td.setLastName("Glow");
        td.setAge(21);
        
        System.out.println("The Details Are: "+ 
                 td.getFirstName() +"\n"+
                 td.getLastName() +"\n"+
                 td.getAge());
        
    }
    
}
