/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question_1;

/**
 *
 * @author KID DANGER
 */
public class Printing {
    
    public void printDetails(CustomerPurchases cp){ //Ouputing Customer and product information
        
        System.out.println("CUSTOMER INVOICE");
        System.out.println("****************");
        System.out.println("CUSTOMER NUMBER\t"+cp.getCustomerNumber());
        System.out.println("CUSTOMER FIRST NAME\t"+cp.getFirstName());
        System.out.println("CUSTOMER SURNAME\t"+cp.getSurname());
        System.out.println("CUSTOMER PRICE\t"+cp.getPrice());
        System.out.println("QUANTITY\t"+cp.getQuantity());
        
    }
    
    public void customerPurcahaseReport(CustomerPurchases cp){ //Outputing Purcahace Report
        
        float tax = Math.round(cp.getPrice()*0.15);
        float commission = Math.round(cp.getPrice()*0.085);
        float discount = Math.round(cp.getPrice()*0.1);
        
        System.out.println("CUSTOMER PURCHASE REPORT");
        System.out.println("************************");
        System.out.println("PRODUCT PRICE\t"+cp.getPrice());
        System.out.println("TAX\t"+tax);
        System.out.println("COMMISION\t"+commission);
        System.out.println("DISCOUNT\t"+discount);
        System.out.println("TOTAL\t"+((cp.getPrice()+tax)-(discount+commission)));
        
    }
    
}
