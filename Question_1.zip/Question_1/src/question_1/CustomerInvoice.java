/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question_1;

import java.util.Scanner;

/**
 *
 * @author KID DANGER
 */
public class CustomerInvoice { //main class used to operate all the other objects

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);//used to collect information from user
        CustomerPurchases cp = new CustomerPurchases();//used to store the information
        Printing p = new Printing();//used to print out the infomation
        
        System.out.println("Please Insert Customer Number >> ");
        cp.setCustomerNumber(sc.nextInt());
        System.out.println("Please Insert First Name >> ");
        cp.setFirstName(sc.next());
        System.out.println("Please Insert Surname >> ");
        cp.setSurname(sc.next());
        System.out.println("Please Insert Product >> ");
        cp.setProduct(sc.next());
        System.out.println("Please Insert Price >> ");
        cp.setPrice(sc.nextFloat());
        System.out.println("Please Insert Quantity Required >> ");
        cp.setQuantity(sc.nextInt());
        
        p.printDetails(cp);
        p.customerPurcahaseReport(cp);
        
    }
    
}
