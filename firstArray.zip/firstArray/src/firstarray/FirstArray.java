/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firstarray;

/**
 *
 * @author KID DANGER
 */
public class FirstArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int [][] firstArray = {
            {2,3},
            {4,5}
        };
        
        
           for (int i = 0; i < firstArray.length; i++) {
              
               for (int j = 0; j < firstArray[i].length; j++) {
                   
                   //System.out.print(firstArray[i][j] + " ");
                   System.out.printf("%5d",firstArray[i][j]);
               }
                System.out.println();
        }
        
        
    }
    
}
