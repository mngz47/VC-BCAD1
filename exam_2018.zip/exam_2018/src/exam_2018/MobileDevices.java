/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam_2018;

import javax.swing.JOptionPane;

/**
 *
 * @author KID DANGER
 */
public class MobileDevices {
    
    private final int [] deviceId = new int[3];
    private final String [] deviceName = new String[3];
    private final double [] devicePrice = new double[3];
    
    public void loadArray(){ //input details for three devices
            for(int a=0;a<deviceId.length;a++){
                
                deviceId[a] = Integer.parseInt(JOptionPane.showInputDialog("Please enter the ID for device "+(a+1)));
                deviceName[a] = JOptionPane.showInputDialog("Please enter name for device "+deviceId[a]);
                devicePrice[a] = Double.parseDouble(JOptionPane.showInputDialog("Please enter price for device "+deviceId[a]));
                
            }
    }
    
    public void searchArray(){
        
        boolean matchFound = false;
        int deviceIdSearch = Integer.parseInt(JOptionPane.showInputDialog("Please enter device ID"));
        
        for (int a=0;a<deviceId.length;a++){
            if(deviceIdSearch == deviceId[a]){
                
                JOptionPane.showMessageDialog(null,
                        "Device ID: "+deviceId[a]+"\n"+
                        "PRODUCT: "+deviceName[a]+"\n"+
                        "PRICE: "+devicePrice[a]+"\n"
                );
                matchFound = true;
                break;
            }
        }
        
        if(!matchFound){
            JOptionPane.showMessageDialog(null, "The device you entered cannot be found!!");
        }
    }
    
    public void showArray(){
        String devices = "ID\t DEVICE\t PRICE\n---------------------------------";
        
        for (int a=0;a<deviceId.length;a++){
               devices +=  "\n"+deviceId[a]+"\t "+
                        deviceName[a]+"\t "+
                       devicePrice[a];
        }
        devices+="\n DEVICE COUNT: 3";
        JOptionPane.showMessageDialog(null,devices);
    }
    
}
