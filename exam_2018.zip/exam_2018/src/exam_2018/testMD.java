/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam_2018;

import javax.swing.JOptionPane;

/**
 *
 * @author KID DANGER
 */
public class testMD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int exit = 0;
        
        MobileDevices mb = new MobileDevices();
        
        while(exit==0){
            
           int input = Integer.parseInt(JOptionPane.showInputDialog("Enter (1) to add devices.\nEnter (2) to search  for device details.\nEnter (3) to desplay all the device details.\nEnter (0) to exit."));
          
           switch(input){
               case 1 : mb.loadArray();break;
               case 2 : mb.searchArray();break;
               case 3 : mb.showArray();break;
               case 0 : exit=1;break;
               default : JOptionPane.showMessageDialog(null, "Invalid Selection");
           }
        }
   
    }
    
}
