/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package distancefromaverage;

import java.util.Scanner;

/**
 *
 * @author 21007487
 */
public class DistanceFromAverage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        double [] d_nums = new double[15];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 15 decimal numbers or 99999 to quit.");
        final int QUIT = 99999;
        double value = 0;
        double total = 0;
        double average;
        
        for(int a=0;a<15 && value!=QUIT;a++){
        
        value = sc.nextDouble();
        
        d_nums[a] = value;
        
        total+=value;
        
        }
        
        average = Math.round(total/15);
      
        System.out.println("\nThe avarage is : "+average+"\n");
        
        for (int i = 0; i < 15; i++) {
            System.out.println(d_nums[i]+" Distance from average : "+((average-d_nums[i])>0?(average-d_nums[i]) : -(average-d_nums[i])));
        }
        
    }
    
}
