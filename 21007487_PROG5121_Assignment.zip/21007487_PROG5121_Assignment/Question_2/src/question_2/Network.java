/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question_2;

import javax.swing.JOptionPane;

/**
 *
 * @author KID DANGER
 */
public class Network {

    /**
     * @param args the command line arguments
     */
   
    
    
    public static void main(String[] args) {
        
       Provider pp = new Provider();
       
       pp.getNames();
       String[] providers = pp.assignProvider();
       String[] cellNumbers = pp.assignCellNumber(providers);
       
       String message = "";
       for(int a=0;a<pp.names.length;a++){
           message += pp.names[a]+" will be on "+providers[a]+" with phone number "+cellNumbers[a]+"\n";
       }
       JOptionPane.showMessageDialog(null, message);
      
    }
    
    
}
