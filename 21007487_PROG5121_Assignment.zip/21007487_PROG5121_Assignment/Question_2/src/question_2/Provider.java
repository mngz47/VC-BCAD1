/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question_2;

import javax.swing.JOptionPane;

/**
 *
 * @author KID DANGER
 */
public class Provider {
    
    String [] names = new String[3];
    
    String [] providers = {"MTN","VODACOM","CELLC"};
    
    public void getNames(){ //Collecting the names to be assigned with Network Provider
         for(int a=0;a<names.length;a++){
            names[a] = JOptionPane.showInputDialog(null,"Enter "+(a>0?"Another":"")+" Name To Assign Network Provider: ");
        }
    }
    
    public String[] assignProvider(){
        String assigned = "";
        
        int index = (int)Math.round(Math.random()*2); //generating random assignment index
        int count = 0;
        
        while(count<providers.length){ //will repeat until each name has been assigned a provider
            
            if(!assigned.contains(providers[index])){ //checking not to assign the same provider to multiple names
            assigned += providers[index]+";"; //assigning the provider
            count++;  
            }
            
            index = (int)Math.round(Math.random()*2); //generating random assignment index
        }
        
                
    return assigned.split(";");
    }
    
   public String[] assignCellNumber(String [] assignedProvider){
       
       String assigned = "";
       
       for(int a=0;a<3;a++){
           switch (assignedProvider[a]) {
               case "MTN":
                   assigned += "083 "+getCellNumber()+";";
                   break;
               case "VODACOM":
                   assigned += "072 "+getCellNumber()+";";
                   break;
               default:
                   assigned += "084 "+getCellNumber()+";";
                   break;
           }
       }
       
       
       return assigned.split(";");
   }
   
   String getCellNumber(){
       return Math.round(Math.random()*1000) +" "+ Math.round(Math.random()*10000);
   }
    
}
