/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package water.usage.pkg2019;

import java.util.Scanner;

/**
 *
 * @author 21007487
 */
public class Water {

    /**
     * @param args the command line arguments
     */
    
    static int customerId;
    
    static int firstMonth;
    
    static int secondMonth;
    
    static int thirdMonth;
    
    public static void main(String[] args) {
       
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Customer Id");
        customerId = sc.nextInt();
        System.out.println("Enter First Month Rainfall");
        firstMonth = sc.nextInt();
        System.out.println("Enter Second Month Rainfall");
        firstMonth = sc.nextInt();
        System.out.println("Enter Third Month Rainfall");
        firstMonth = sc.nextInt();
        
        printRainfall();
        
    }
    
    public static int getTotalRainfall(){
        return (firstMonth+secondMonth+thirdMonth);
    }
    
    public static int getAverageRainfall(){
        return Math.round(getTotalRainfall()/3);
    }
    
    public static void printRainfall(){
        System.out.println("Total Rainfall: "+getTotalRainfall());
        System.out.println("Average Rainfall: "+getAverageRainfall());
    }
    
}
