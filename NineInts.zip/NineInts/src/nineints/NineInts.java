/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nineints;

import java.util.Scanner;

/**
 *
 * @author 21007487
 */
public class NineInts {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        int [] numbers = new int[9];
        
        Scanner sc = new Scanner(System.in);
        
       // System.out.println("Do you want to use default values? (Y/N)");
        
        System.out.println("Enter 9 Numbers");
        for(int a=0;a<9;a++){
            numbers[a] = sc.nextInt();
        }
        System.out.println("Numbers In Correct Order");
        for(int a=0;a<9;a++){
         System.out.print(numbers[a]+"; ");
        }
        System.out.println("\nNumbers In Reverse");
        for(int b=numbers.length-1;b>-1;b--){
           System.out.print(numbers[b]+"; "); 
        }
        
    }
    
}
