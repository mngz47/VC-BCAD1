/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author KID DANGER
 */
public abstract class Student implements iReport {
  
    String student_number;
    
    int test_result;
    
    int assignment;
    
    int exam;
    
    @Override
    public void print_report(){
        
        System.out.println("Student Report");
        System.out.println("**************");
        
        System.out.println("STUDENT NUMBER :" + student_number);
        System.out.println("TEST WEIGHING :" + test_result);
        System.out.println("ASSIGNMENT WEIGHING :" + assignment);
        System.out.println("EXAM WEIGHING :" + exam );
        System.out.println("FINAL RESULT :" + (test_result+assignment+exam));
        
    }   
}
