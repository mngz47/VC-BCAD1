/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vacation.countries;

import java.util.Scanner;

/**
 *
 * @author 21007487
 */
public class VacationPlanner {

    /**
     * @param args the command line arguments
     */
   
                                            
    
    int hotels;
    
    int museums;
                               
                            //[hotels][museums] 
    String [][] countries = 
            
    {
         {},  
         {},  
         {},
         
    };
    
    
   void index(){
       Scanner sc = new Scanner(System.in);
       
       System.out.println("Vacation Planner");
       System.out.println("*****************");
       System.out.println("Find country with the best options!");
       System.out.println("*****************");
       
       System.out.println("Enter number of hotel options you want");
       hotels = Integer.parseInt(sc.next());
       System.out.println("Enter number of hotel options you want");
       museums = Integer.parseInt(sc.next());
       
        if(hotels<20){
            if(museums<5){
                System.out.println("The country for your is "+countries[hotels][museums]);
            }else{
        System.out.println("Only countries with MAX 5 museums are listed");        
            }   
        }else{
        System.out.println("Only countries with MAX 20 top hotels are listed");    
        } 
        
        
        System.out.println("Are you happy with your result? (y/n)");
        String feedback = sc.next();
        
   }
   
   
   void updateCountry(){
       
       
       
       
   }
   
   
   
   
}
